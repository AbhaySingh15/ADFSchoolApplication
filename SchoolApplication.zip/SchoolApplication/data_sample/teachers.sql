--------------------------------------------------------
--  File created - Saturday-September-22-2018   
--------------------------------------------------------
REM INSERTING into SCHOOL.TEACHERS
SET DEFINE OFF;
Insert into SCHOOL.TEACHERS (TEACHER_ID,TEACHER_NAME,TEACHER_PHONE,TEACHER_ADDRESS,TEACHER_DATE_OF_BIRTH,TEACHER_GENDAR) values (1,'Teacher 1',null,'Ireland',to_timestamp('07-SEP-85','DD-MON-RR HH.MI.SSXFF AM'),'M');
Insert into SCHOOL.TEACHERS (TEACHER_ID,TEACHER_NAME,TEACHER_PHONE,TEACHER_ADDRESS,TEACHER_DATE_OF_BIRTH,TEACHER_GENDAR) values (2,'Teacher 2',null,'UK',to_timestamp('18-SEP-86','DD-MON-RR HH.MI.SSXFF AM'),'F');
Insert into SCHOOL.TEACHERS (TEACHER_ID,TEACHER_NAME,TEACHER_PHONE,TEACHER_ADDRESS,TEACHER_DATE_OF_BIRTH,TEACHER_GENDAR) values (4,'Teacher 4',null,'Ireland',to_timestamp('25-SEP-86','DD-MON-RR HH.MI.SSXFF AM'),'M');
Insert into SCHOOL.TEACHERS (TEACHER_ID,TEACHER_NAME,TEACHER_PHONE,TEACHER_ADDRESS,TEACHER_DATE_OF_BIRTH,TEACHER_GENDAR) values (5,'Teacher 3',null,'US',to_timestamp('19-SEP-85','DD-MON-RR HH.MI.SSXFF AM'),'M');
