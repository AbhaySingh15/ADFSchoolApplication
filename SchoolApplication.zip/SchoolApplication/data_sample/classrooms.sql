--------------------------------------------------------
--  File created - Saturday-September-22-2018   
--------------------------------------------------------
REM INSERTING into SCHOOL.CLASSROOMS
SET DEFINE OFF;
Insert into SCHOOL.CLASSROOMS (ROOM_NUMBER,GRADE_NUMBER) values (3,'G1');
Insert into SCHOOL.CLASSROOMS (ROOM_NUMBER,GRADE_NUMBER) values (1,'G1');
Insert into SCHOOL.CLASSROOMS (ROOM_NUMBER,GRADE_NUMBER) values (2,'G1');
Insert into SCHOOL.CLASSROOMS (ROOM_NUMBER,GRADE_NUMBER) values (4,'G2');
Insert into SCHOOL.CLASSROOMS (ROOM_NUMBER,GRADE_NUMBER) values (5,'G3');
Insert into SCHOOL.CLASSROOMS (ROOM_NUMBER,GRADE_NUMBER) values (6,'G4');
Insert into SCHOOL.CLASSROOMS (ROOM_NUMBER,GRADE_NUMBER) values (7,'G4');
Insert into SCHOOL.CLASSROOMS (ROOM_NUMBER,GRADE_NUMBER) values (8,'G5');
Insert into SCHOOL.CLASSROOMS (ROOM_NUMBER,GRADE_NUMBER) values (9,'G6');
