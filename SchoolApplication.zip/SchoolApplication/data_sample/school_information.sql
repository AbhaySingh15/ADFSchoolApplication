--------------------------------------------------------
--  File created - Saturday-September-22-2018   
--------------------------------------------------------
REM INSERTING into SCHOOL.SCHOOL_INFORMATION
SET DEFINE OFF;
Insert into SCHOOL.SCHOOL_INFORMATION (SCHOOL_NAME,SCHOOL_ADDRESS,SCHOOL_EMAIL,SCHOOL_PHONE,SCHOOL_FAX,SCHOOL_PRINCIPAL_NAME,SCHOOL_PRINCIPAL_USERNAME,SCHOOL_PRINCIPAL_PASWORD) values ('My School Name',null,null,null,null,'Admin','admin','admin');
