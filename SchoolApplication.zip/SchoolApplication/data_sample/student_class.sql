--------------------------------------------------------
--  File created - Saturday-September-22-2018   
--------------------------------------------------------
REM INSERTING into SCHOOL.STUDENT_CLASS
SET DEFINE OFF;
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (9,1);
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (10,2);
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (13,1);
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (11,1);
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (12,2);
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (14,5);
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (15,8);
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (16,7);
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (17,9);
Insert into SCHOOL.STUDENT_CLASS (STUDENT_FK,CLASSROOM_FK) values (18,6);
